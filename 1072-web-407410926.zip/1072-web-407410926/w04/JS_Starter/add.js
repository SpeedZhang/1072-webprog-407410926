alert('Hi');

let input = prompt('Enter your name');
console.log(input);